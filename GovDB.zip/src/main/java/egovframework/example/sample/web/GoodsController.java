package egovframework.example.sample.web;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import egovframework.example.sample.service.GoodsService;

@Controller
public class GoodsController {
	@Resource(name = "GoodsService")
	private GoodsService goodsService;
	
	@RequestMapping(value = "/goodsList.do")
	public String selectSampleList(Model model) throws Exception {
		List<?> goodsList = goodsService.selectGoods();
		model.addAttribute("resultList", goodsList);
		return "sample/goodsList";
	}
	


}
