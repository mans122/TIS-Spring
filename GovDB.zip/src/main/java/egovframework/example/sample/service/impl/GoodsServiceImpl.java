package egovframework.example.sample.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import egovframework.example.sample.service.GoodsService;
import egovframework.rte.fdl.cmmn.EgovAbstractServiceImpl;

@Service("GoodsService")
public class GoodsServiceImpl extends EgovAbstractServiceImpl implements GoodsService {
	@Resource(name="GoodsDAO")
	private GoodsDAO GoodsDAO;
	
	@Override
	public List<?> selectGoods() throws Exception {
		
		return GoodsDAO.selectGoods();
	}

}
