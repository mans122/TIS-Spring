package egovframework.example.sample.service;

import java.util.List;

public interface GoodsService {
	public List<?> selectGoods() throws Exception;
}
