package egovframework.example.sample.service.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import egovframework.rte.psl.dataaccess.EgovAbstractDAO;

@Repository("GoodsDAO")
public class GoodsDAO extends EgovAbstractDAO {
	public List<?> selectGoods() throws Exception {
		return list("selectGoods");
	}
}
