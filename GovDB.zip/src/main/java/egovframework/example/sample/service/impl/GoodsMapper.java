package egovframework.example.sample.service.impl;

import java.util.List;

import egovframework.rte.psl.dataaccess.mapper.Mapper;

@Mapper("GoodsMapper")
public interface GoodsMapper {
	public List<?> selectGoods() throws Exception;
}
